package com.facebook.report.myapp;

// Splash Activity placeholder